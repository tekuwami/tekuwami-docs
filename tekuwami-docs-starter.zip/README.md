# Tekuwami Docs (Public)

**What this is:** A lightweight docs + samples site you can publish on GitHub Pages. It helps technical buyers quickly understand Tekuwami and *verify* the outputs (CSV/GeoJSON).

**Live product:** https://portal.tekuwami.com.et/  
**Overview:** https://tekuwami.com.et/

## Contents
- `docs/getting-started.md` — 10‑minute quick start
- `samples/sample_records.csv` — example CSV export (tabular)
- `samples/sample_points.geojson` — example GeoJSON export (map‑ready)
- `samples/form_schema.json` — example Tekuwami form schema

## Why public samples?
Decision‑makers and engineers want to see clean outputs. Publishing **realistic sample exports** builds trust that Tekuwami is ready for analysis, GIS, and climate finance workflows.

## How to publish on GitHub Pages (3 steps)
1. Create a new GitHub repo, e.g. `tekuwami-docs`.
2. Upload these files. In repo **Settings → Pages**, set **Branch: main** and folder **`/ (root)`** (or `/docs` if you prefer).
3. Your docs will be live at `https://<your-username>.github.io/tekuwami-docs/`

> Tip: Put your quick start under `/docs/getting-started.md` and enable Pages with **/docs** as the source to map directly.
