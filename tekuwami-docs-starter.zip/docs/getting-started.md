# Getting Started (10 minutes)

Tekuwami turns **field data** (GPS, photos, forms) into **analysis‑ready outputs** for adaptation decisions.

## 1) Try the product
- Go to **https://portal.tekuwami.com.et/**
- Sign up → Create a **Form** (e.g., “Crop Stress Survey”)
- Add fields: `crop` (text), `moisture` (dropdown), `damage_score` (number), `photo` (image), `location` (GPS)
- Use the **Android app** to capture a few records **offline**; sync when online

## 2) Export your data
- Portal → **Exports** → choose **CSV** or **GeoJSON**
- CSV is great for spreadsheets/BI; GeoJSON is map‑ready (QGIS, kepler.gl, Mapbox)

See sample exports:
- [`samples/sample_records.csv`](../samples/sample_records.csv)
- [`samples/sample_points.geojson`](../samples/sample_points.geojson)

## 3) Analyze quickly
- **CSV** → Excel/Sheets/Power BI/Tableau
- **GeoJSON** → QGIS / kepler.gl / Mapbox Studio

## 4) (Optional) Programmatic access
- Use your institution’s export endpoint (admin‑enabled) to fetch latest submissions.
- Example (pseudo‑curl):

```bash
curl -H "Authorization: Bearer <YOUR_TOKEN>"   "https://api.tekuwami.com/export?institutionId=<ID>&format=geojson"
```

> Contact support for API access. We recommend starting with the portal exports first.

## 5) Data governance
- Role‑based access (Admin / Field Agent)
- Full audit trail; offline‑first sync
- Data sovereignty options with BYOC storage

---

**Questions?** partnership@tekuwami.com.et
